package mavenproject.mavendemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;






public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("NewFile.xml");

		
		Student s=(Student)context.getBean("s1");
		s.display();
		
		Book b=(Book)context.getBean("b1");
		b.display();
		
		Employee e=(Employee)context.getBean("e1");
		e.display();
		
    }
}
