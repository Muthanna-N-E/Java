package mavenproject.mavendemo;

public class Student {

	String Stuname,id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStuname() {
		return Stuname;
	}

	public void setStuname(String stuname) {
		Stuname = stuname;
	}
	void display()
	{
		System.out.println("Student Details\nName : " +Stuname+"\nId: "+id);
	}
}
