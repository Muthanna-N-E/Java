package mavenproject.mavendemo;

public class Book {
	String Id,Publisher,Price;

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getPublisher() {
		return Publisher;
	}

	public void setPublisher(String publisher) {
		Publisher = publisher;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	void display()
	{
		System.out.println("\nBook Details\nId: "+Id+"\nPublisher: "+Publisher+"\nPrice: "+Price);
	}

}
