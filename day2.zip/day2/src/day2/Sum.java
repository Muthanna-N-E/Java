package day2;

public class Sum {

	public static void main(String[] args) {
		int count=20, num1=0,num2=1;
		
		int i=1;
		while(i<=count)
		{
			System.out.println(num1);
			int sum=num1+num2;
			num1=num2;
			num2=sum;
			i++;
		}
		
		
		int a=0,b=1,temp=1,j=1;
		do
		{
			a=b;
			b=temp;
			temp=a+b;
			System.out.print(temp);
			j++;
		}
		while(temp<100);

	}

}
