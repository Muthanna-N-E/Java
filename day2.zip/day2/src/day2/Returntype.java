package day2;

import java.util.Scanner;

public class Returntype {
	
	
	public int oddeven(int i)
	{
		
		int a,b;
			if(i%2==0)
			{
				return a;
			}
			else
			{
				return b;
			}

		
	}

	public static void main(String[] args) {
		
		
		Returntype n=new Returntype();
		
		
		System.out.print("The sum of odd numbers upto "+num+ "="+odd);

	}

}
