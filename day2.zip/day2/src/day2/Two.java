package day2;

public class Two {

	public static void main(String[] args) {
		Car c=new Car("Lamborgini", "Murcilago");
		System.out.print(c.getDetails());

	}

}

class Car

{
	String brandName, price;
	Car(String b,String p)
	{
		brandName=b;
		price=p;
	}
	String getDetails()
	{
		return brandName+" "+price;
	}
}



class Area
{
	int circle,rectangle,square;
	
}