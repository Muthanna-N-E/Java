package day2;

public class Tableofno {

	public static void main(String[] args) {
		int num=5;
		int i=1;
		while(i<=10)
		{
			System.out.println(num*i);
			i++;
		}
		
//		do while
		
		int n=2;
		int j=1;
		do
		{
			System.out.println(n*j);
			j++;
		}
		while(j<=10);

	}

}
