package day2;

import java.util.Scanner;

public class New {
	
	void abc(int num)
	{
	int i,fact=1 ;
	

	for(i=1;i<=num;i++)
	{
		fact=fact*i;
	}
	System.out.println(fact);
	}
	
	
//	void qaz()
//	{
//		float a,b,sum;
//		Scanner s=new Scanner(System.in);
//		System.out.print("Enter the first no");
//		a=s.nextFloat();
//		System.out.print("Enter the second no");
//		b=s.nextFloat();
//		sum=a+b;
//		System.out.print(sum);
//		
//	}
	
	
	void sum(double x,double y)
	{
		System.out.print(x+y);
	}
	
	
	void areacircle(float r)
	{
		System.out.print("Area of circle "+(Math.PI*r*r));
	}
	
	void arearectangle(float l, float b)
	{
		System.out.print("Area of rectangle "+(l*b));
	}
	
	void areasquare(float s)
	{
		System.out.print("Area of square "+(s*s));
	}

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		New n=new New();
		System.out.print("Enter a number");
		int i=s.nextInt();
		n.abc(i);
		
		
		n.sum(34.5,665.76);
		
		
		System.out.print("Enter the area of circle ");
		int a=s.nextInt();
		n.areacircle(a);
		
		System.out.print("Enter the area of rectangle ");
		int l=s.nextInt();
		int b=s.nextInt();
		n.arearectangle(l,b);
		
		System.out.print("Enter side ");
		int side1=s.nextInt();
		n.areasquare(side1);
		
	
	}

}
