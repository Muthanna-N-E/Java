package day2;

public class Facto {

	public static void main(String[] args) {
		int n=6;
		int i=1;
		long facto=1;
		do
		{
			facto=facto*i;
			i++;
			
		}
		while(i<=n);
		System.out.println(n);

	}

}
