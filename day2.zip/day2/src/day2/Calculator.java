package day2;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		char choice;
		Scanner s=new Scanner(System.in);
		do {
	    System.out.println("Enter the first No: ");
		int num1=s.nextInt();
		System.out.println("Enter the second No: ");
		int num2=s.nextInt();
		System.out.println("Enter yor choice: ");
		System.out.println("Addition ");
		System.out.println("Sub ");
		System.out.println("Mul ");
		System.out.println("Div ");
		int ch=s.nextInt();
		if(ch==1)
		{
			System.out.println(num1+num2);
		}
		else if(ch==2)
		{
			System.out.println(num1-num2);
		}
		else if(ch==3)
		{
			System.out.println(num1*num2);
		}
		else if(ch==4)
		{
			System.out.println(num1/num2);
		}
		else
		{
			System.out.println("Enter valid choice(1,2,3,4)");
		}
		System.out.println("Do you want to continue ? (y/n)");
		choice=s.next().charAt(0);
		}
		while(choice=='y' || choice=='Y');
		System.out.println("Thanj"
				+ "k You !!");
		

	}

}
