package day2;

import java.util.Scanner;

public class Bill {

	public static void main(String[] args) {
		char choice;
		Scanner s=new Scanner(System.in);
		do {
		System.out.println("Enter your choice:\n1.Breakfast \n2.Lunch\n3.Dinner\n");
		int ch=s.nextInt();
		if(ch==1)
		{
			System.out.println("1.Coffe\n2.Sandwich\n3.Coffe & Sandwich");
			int b=s.nextInt();
			if(b==1) {
				System.out.print("Bill is: Rs.80");
			}
			else if(b==2)
			{
				System.out.println("Bill is: Rs.250");
			}
			else
			{
				System.out.println("Bill is: Rs.330");
			}
		}
		else if(ch==2)
		{
			System.out.println("1.Veg Meals\n2.Non-veg Meals");
			int b=s.nextInt();
			if(b==1) {
				System.out.print("Bill is: Rs.300");
			}
			else
			{
				System.out.println("Bill is: Rs.550");
			}
			
		}
		else
		{
			System.out.println("1.Fried Rice\n2.Noodles");
			int b=s.nextInt();
			if(b==1) {
				System.out.print("Bill is: Rs.250");
			}
			else
			{
				System.out.println("Bill is: Rs.180");
			}
			
		}
		System.out.println("Do you want to order something else ?(y/n)");
		choice=s.next().charAt(0);
		}
		while(choice=='y' ||choice=='Y');
			System.out.print("Thank you");

	}

}
