package day2;

public class Area {

	public static void main(String[] args) {
		Circle c=new Circle(24);
		System.out.print(c.getArea());
		Rectangle r=new Rectangle(2,4);
		System.out.print(r.getArea());
		Square s=new Square(6);
		System.out.print(s.getArea());
		

	}

}


class Circle
{
	double radius;
	Circle(double r)
	{
		radius=3.14*r*r;
	}
	double getArea()
	{
		return radius;
	}
}
	
	class Rectangle
	{
		float length,breadth,area;
		Rectangle(float l,float b)
		{
			length=l;
			breadth=b;
			area=l*b;
		}
		float getArea()
		{
			return area;
		}
	}
	
	class Square
	{
		float side;
		Square(float s)
		{
			side=s*s;
			
		}
		float getArea()
		{
			return side;
		}
	}
	
