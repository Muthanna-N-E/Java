/**
 * 
 */
/**
 * @author 00005730
 *
 */
module day2 {
}