package projectmaven.projmvn;

import java.util.Scanner;

public class Salary {

	public Salary() {

		Scanner s=new Scanner(System.in);
		System.out.println("The employee salary details");
		}
		void display() {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number of days employee worked");
		int worked=s.nextInt();
		int perday=1000;
		int salary=worked*perday;
		System.out.println("The Salary of the employee is:Rs."+salary);
		}
}
