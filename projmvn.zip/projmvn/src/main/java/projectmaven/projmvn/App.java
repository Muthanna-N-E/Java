package projectmaven.projmvn;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("NewFile.xml");
        MessagePass pass=(MessagePass)context.getBean("msgpass");
        pass.displaymsg();
        
        Student stu=(Student)context.getBean("adds");
        stu.displayadd();
        
        Employee empp=(Employee)context.getBean("emp");
        empp.displaysal();
    }
}
