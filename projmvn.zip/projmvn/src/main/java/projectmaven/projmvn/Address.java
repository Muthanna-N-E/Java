package projectmaven.projmvn;

public class Address {
	
	public Address()
	{
		System.out.println("adsag#hsb11w-2345");
		
	}
	void display()
	{
		System.out.println("gdfghjg@12345");
		
	}

}
