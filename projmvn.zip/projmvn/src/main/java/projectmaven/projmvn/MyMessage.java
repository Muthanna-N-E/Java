package projectmaven.projmvn;



public class MyMessage {
	
	public MyMessage()
	{
		System.out.print("inside constructor");
	}
	void display()
	{
		System.out.print("inside method...");
	}

}
