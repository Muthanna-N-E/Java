package springdemo;

public class Student {
	String Stuname;

	public String getStuname() {
		return Stuname;
	}

	public void setStuname(String stuname) {
		Stuname = stuname;
	}
	void display()
	{
		System.out.print("Name : " +Stuname);
	}

}
