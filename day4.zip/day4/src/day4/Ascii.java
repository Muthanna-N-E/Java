package day4;

import java.util.Scanner;

public class Ascii {

	public static void main(String[] args) {
		  char ch;
	      int ascii;
	      Scanner s = new Scanner(System.in);
	      System.out.print("Enter a Character: ");
	      ch = s.next().charAt(0);     
	      ascii = ch;
	      System.out.println("\nASCII Value = " +ascii);

	}

}
