package day4;

public class Power {

	public static void main(String[] args) {
		 int basenumber = 2, exponent = 3;
		  double power = Math.pow(basenumber, exponent);
		  System.out.println("Result: " + power);

	}

}
