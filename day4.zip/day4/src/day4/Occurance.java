package day4;

public class Occurance {

	public static void main(String[] args) {
		String str="muthanna";
		int count=0;
		char c='a';
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)==c)
			{
				count++;
			}
		}
		System.out.println("Repeated character is: "+count);

	}

}
