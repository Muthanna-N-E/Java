package day4;

public class Test1 {

	public static void main(String[] args) {
		MyClass c=new MyClass();
		c.meth1();
		c.meth2();

	}

}



interface A
{
	void meth1();
	void meth2();
}

class MyClass implements A
{
	public void meth1()
	{
		System.out.println("abc");
	}
	public void meth2()
	{
		System.out.println("def");
	}
}