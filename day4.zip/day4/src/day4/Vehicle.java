package day4;

public class Vehicle {

	public static void main(String[] args) {
		Car c=new Car();
		c.tuneUpCost();
		c.canCarry(3);

	}

}



interface IVehicle {
    // indicate how much a basic tune-up costs
    public double tuneUpCost();
  
    // determine whether vehicle can hold given num of passengers
    public boolean canCarry(int numPassengers);
  }

class Car implements IVehicle
{
	 public double tuneUpCost()
	 {
		 System.out.println("The total cost is Rs.15,000");
		 return 0;
	 }
	 public boolean canCarry(int numPassengers)
	 {
		 
		 if(numPassengers==5)
		 {
		System.out.println("The vehicle can hold 5 passengers");
		return true;
	 }
		 else {
			 System.out.print("The vehicle is not suitable");
			 return false;
		 }
}
}