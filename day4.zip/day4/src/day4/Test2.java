//package day4;
//
//public class Test2 {
//
//	public static void main(String[] args) {
//		
//		Sound s=new Sound();
//		s.eat();
//		s.makeSound();
//		Bike m=new Bike();
//		m.brake();
//
//	}
//
//}
//
//abstract class Animal {
//	  abstract void makeSound();
//
//	  public void eat() {
//		  System.out.print("zzz");
//	   
//
//
//	  }
//	}
//
//
//class Sound extends Animal
//{
//	void makeSound() {
//		System.out.print("eat");
//	}
//}
//
//abstract class MotorBike 
//{
//	abstract void brake();
//}
// 
//class Bike extends MotorBike
//{
//	void brake()
//	{
//		System.out.println("Brake applied");
//	
//	}
//}
//​​​​​​



