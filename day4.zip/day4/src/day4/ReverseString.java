package day4;

import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {
		String str;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the String");
		str=s.nextLine();
		System.out.println("Reverse of the String "+str+" is" );
		for(int i=str.length();i>0;i--)
		{
			System.out.println(str.charAt(i-1));
		}
	}

}
