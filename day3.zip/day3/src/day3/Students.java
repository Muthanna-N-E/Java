package day3;

import java.util.Scanner;



public class Students {
	
	

	public static void main(String[] args) {
		 Results r=new Results();
         r.readDetails();
         r.readMarks();
         r.displayDetails();
         r.displayMarks();
         r.Calculate();
         r.DisplayResult();
	}
}
	

class Student{
    Scanner s=new Scanner(System.in);
	int studentId;
	String studentname,phone;
	 
	void readDetails()
	{
	    System.out.println("Enter id");
	    studentId=s.nextInt();
	    System.out.println("Enter name");
	    studentname=s.next();
	    System.out.println("Enter phone");
	    phone=s.next();
	}
	 
	void displayDetails()
	{
	    System.out.println("ID :"+studentId);
	    System.out.println("Name:"+studentname);
	    System.out.println("Phoneno :"+phone);
	}
	}
	 
	class Marks extends Student
	{
	    int m1,m2,m3;
	 
	    void readMarks()
	    {
	        System.out.println("marks of Maths");
	        m1=s.nextInt();
	        System.out.println("marks of English");
	        m2=s.nextInt();
	        System.out.println("marks of Hindi");
	        m3=s.nextInt();
	    }

	    void displayMarks()
	    {
	        System.out.println("Marks ---\nMaths:"+m1);
	        System.out.println("English:"+m2);
	        System.out.println("hindi:"+m3);

	    }
	}
	
	
	class Results extends Marks
	{
		int TotalMarks,Percentage;
		String Grade;
		
		void Calculate()
		{
	        TotalMarks=m1+m2+m3;
	        Percentage=(TotalMarks*100)/300;
	        if(Percentage>=85)
	        {
	        	Grade="First Class";
	        }
	        else if(Percentage>=60 && Percentage<=84)
	        {
	        	Grade="Second Class";
	        }
	        else if(Percentage>=40 && Percentage<=59)
	        {
	        	Grade="Third Class";
	        }
	        else
	        {
	        	Grade="Fail";
	        }
	        

		}
		
		void DisplayResult()
		{
	        System.out.println("Total Marks:"+TotalMarks);
	        System.out.println("Percentage:"+Percentage);
	        System.out.println("Grade:"+Grade);

		}
	}
	

