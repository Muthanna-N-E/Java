package day3;

public class Test {
	String name,rollno;
	


	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}



	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	
	public String getRollno() {
		return rollno;
	}



	

	public static void main(String[] args) {
		
		Test t=new Test();
		t.setName("Ram");
		t.setRollno("123");
		System.out.print(t.getName()+" "+t.getRollno());
		
		

	}


	

}
