package day3;

public class Test1 {

	public static void main(String[] args) {
		 Result r=new Result();
         r.readDetails();
         r.readMarks();
         r.displayDetails();
         r.displayMarks();
         r.Calculate();
         r.DisplayResult();

	}

}
