package phpmaven.mavenphp;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeOperations {
	JdbcTemplate jdbcTemplate;
	

	
//	public JdbcTemplate getJdbcTemplate() {
//		return jdbcTemplate;
//	}



	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}



	int insert(Employee emp)
	{
		String email=emp.getEmail();
		String id=emp.getId();
		String name=emp.getName();
		String salary=emp.getSalary();
		
		String query="insert into employee values('"+name+"','"+id+"','"+email+"','"+salary+"')";
		int result=jdbcTemplate.update(query);
		return result;
	}

}
