package phpmaven.mavenphp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("config.xml");
    	EmployeeOperations op=(EmployeeOperations)context.getBean("operationdemo");
    	Employee el=new Employee();
    	el.setEmail("xyz@gmd");
    	el.setId("555");
    	el.setName("Shellby");
    	el.setSalary("50000");
    	int result=op.insert(el);
    	System.out.print(result);
    	
      
    }
}
