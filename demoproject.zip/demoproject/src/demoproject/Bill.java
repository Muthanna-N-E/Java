package demoproject;

public class Bill {

	public static void main(String[] args) {
		//bill for electricity
		//units
		//50 units are free
		//51-100 units cost Rs6
		//101-150 units cost Rs 8
		//151-total units cost Rs 9
		
		int units=100;
		if(units<=50)
		{
			System.out.print("Units are free");
		}
		else if(units>=51 && units<=100)
		{
			units=(units-50)*6;
			System.out.print(units);
		}
		else if(units>=100 && units<=150)
		{
			units=(units-100)*8+(50*6);
			System.out.print(units);
		}
		else
		{
			units=(units-150)*9+(50*6)+(50*8);
			System.out.print(units);
		}
	}
}