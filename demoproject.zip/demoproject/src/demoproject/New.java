package demoproject;

public class New {

	public static void main(String[] args) {
	 
		int num=5;
		if(num % 2==0)
			System.out.print("Number is even");
		else
			System.out.print("Number is odd");

	}

}
