package demoproject;

public class Postive {

	public static void main(String[] args) {
		
		int num=-2;
		if(num>0)
			System.out.print("Positive number");
		else
			System.out.print("Negative number");

	}

}
