package demoproject;

public class Simpleintrest {

	public static void main(String[] args) {
		 float p,r,t,si;
		 p=1300;
		 r=12;
		 t=2;
		 si=(p*r*t)/100;
		 System.out.print("Simple interst is "+si);

	}

}
