package demoproject;

public class Primeno {

	public static void main(String[] args) {
		int num=19;
		boolean temp=false;
		for(int i=2;i<=num/2;i++) {
			if(num%i==0) {
				temp=true;
				break;
			}

	}
	if(!temp)
		System.out.print(num+" is a prime number");
	else
		System.out.print(num+" is not a prime number");
}
	

}
