package demoproject;

public class Greatest {

	public static void main(String[] args) {
		int num1=10,num2=20,num3=30;
		if(num1>num2 && num1>num3)
			System.out.print(num1+"is the largest number");
		else if(num2>num1 && num2>num3)
			System.out.print(num2+"is the largest number");
		else 
			System.out.print(num3+"is the largest number");

	}

}
