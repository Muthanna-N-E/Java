package demoproject;

public class Grt {

	public static void main(String[] args) {
		int num1=10,num2=20,num3=30,num4=5;
		if(num1>num2 && num1>num3 && num1>num4)
			System.out.print(num1+"is the largest number");
		else if(num2>num1 && num2>num3 && num2>num4)
			System.out.print(num2+"is the largest number");
		else if(num3>num1 && num3>num2 && num3>num4)
			System.out.print(num3+"is the largest number");
		else
			System.out.print(num4+" is the largest number");

	}

}
