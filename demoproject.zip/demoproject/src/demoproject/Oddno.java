package demoproject;

public class Oddno {

	public static void main(String[] args) {
		

		int num=5, odd=0;
		for(int i=1;i<=num;i++)
		{
			if(i%2!=0)
			{
				odd=odd+i;
			}
		}
		System.out.print("The sum of odd numbers upto "+num+ "="+odd);
		
	}

}
