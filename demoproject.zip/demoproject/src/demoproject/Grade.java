package demoproject;

public class Grade {

	public static void main(String[] args) {
		int num=30;
		if(num>=85 && num<=100)
			System.out.print("A");
		else if(num>=35 && num<=84)
			System.out.print("B");
		else
			System.out.print("C");

	}

}
