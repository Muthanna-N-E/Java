package demoproject;

public class test {

	public static void main(String[] args) {
		
		String name="Muthanna";
		String course="Java";
		int age=22;
		System.out.println("My Details:");
		System.out.println("My Name:"+ name);
		System.out.println("My Age:"+ age);
		System.out.println("I am learning:"+ course);

		
	}

}
