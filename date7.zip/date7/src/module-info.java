/**
 * 
 */
/**
 * @author 00005730
 *
 */
module date7 {
}