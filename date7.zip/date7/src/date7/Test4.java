package date7;

public class Test4 {

	public static void main(String[] args) {
		int numbers[]= {20,34,34,31,55};
		for(int i=0;i<numbers.length;i++)
		{
			System.out.println(numbers[i]);
		}
		
		
		 
    

	}

}
