package date7;

public class Test3 {

	public static void main(String[] args) {
		int number=-2;
		try
		{
			
		
		if(number<0)
		{
			throw new Negative("Negative Exception");
		}
		}
		catch(Negative n)
		{
			System.out.println(n);
		}

	}

}

class Negative extends Exception
{
	public Negative(String message)
	{
		super(message);

	}

}
