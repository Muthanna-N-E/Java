package date7;

public class Test2 {

	public static void main(String[] args) {
		int marks=100;
		try
		{
			
		
		if(marks<=200)
		{
			throw new Fail("Failed");
		}
		}
		catch(Fail f)
		{
			System.out.println(f);
		}

	}

}

class Fail extends Exception
{
	public Fail(String message)
	{
		super(message);
	}
}
