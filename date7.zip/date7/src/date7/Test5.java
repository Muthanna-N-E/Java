package date7;

public class Test5 {

	public static void main(String[] args) {
		char vowels[]= {'a','e','i','o','u'};

	    for(int i=0;i<vowels.length;i++)
	    {
	        System.out.println(vowels[i]);
	    }
	
	    
	    

	}

}
