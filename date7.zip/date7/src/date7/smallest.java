package date7;

import java.util.Scanner;

public class smallest {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter the size of array");
		int size=s.nextInt();
		int num[]=new int[size];
		System.out.println("enter the array element");
		for(int i=0;i<size;i++)
		{
			num[i]=s.nextInt();
		}
		
		int min=num[0];
		for(int i=0;i<size;i++)
		{
			if(num[i]<min)
			{
			min=num[i];	
			}
		}
		
		System.out.println("largest number in array " +min);

	}

}
