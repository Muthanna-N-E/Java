package date7;

public class Handling {

	public static void main(String[] args) {
		try {
			String var=null;
			System.out.print(var.charAt(3));
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
		
		
		for(int i=1;i<=10;i++)
	    {
	        try {
	        if(i==5)
	        {
	           i=i/0;
	        }
	        System.out.println(i);
	        }
	        catch(Exception e)
	        {
	            System.out.println("Exception in code : "+e);
	        }

	    }

	}

}
