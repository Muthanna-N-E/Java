package date7;

import java.util.Scanner;

public class Averagearray {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter the size of array");
		int size=s.nextInt();
		int num[]=new int[size];
		System.out.println("enter the array element");
		for(int i=0;i<size;i++)
		{
			num[i]=s.nextInt();
		}
		
		int sum=0;
		for(int i=0;i<num.length;i++)
		{
			sum=sum+num[i];
		}
		int res=sum/size;
		System.out.println("The average array element "+res);

	}

}
