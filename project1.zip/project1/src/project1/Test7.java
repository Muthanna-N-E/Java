package project1;

import java.util.ArrayList;

public class Test7 {

	public static void main(String[] args) {
		ArrayList<books> list=new ArrayList<>();//Object
		books s1=new books("abc", 1,"Rs.500","author1");
		books s2=new books("qwer", 2,"Rs.300","author2");
		books s3=new books("zxcv", 3,"Rs.100","author3");    
		books s4=new books("yhgs", 4,"Rs.400","author4");

          list.add(s1);
          list.add(s2);
          list.add(s3);
          list.add(s4);
          for( books s:list)
          {
              System.out.println(s.bookname+"  "+s.id+" "+s.price+" "+s.author);
          }
}
 
}
 

class books
{
    String bookname,price,author;
    int id;
    public books(String bookname,int id, String price,String author) {
        super();
        this.bookname = bookname;
        this.id = id;
        this.price = price;
        this.author =author;


	}

}

//3. books
//bookname,id,price,author
//
