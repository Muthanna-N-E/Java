package project1;

import java.util.ArrayList;

public class Test6 {

	public static void main(String[] args) {
		 ArrayList<Students> list=new ArrayList<>();//Object
	        Students s1=new Students("Rossi", "250/500","200/500","460/500");
	        Students s2=new Students("Louis", "150/500","300/500","260/500");
	        Students s3=new Students("Vettel", "450/500","100/500","360/500");    
	        Students s4=new Students("Ken", "270/500","400/500","260/500");

	          list.add(s1);
	          list.add(s2);
	          list.add(s3);
	          list.add(s4);
	          for( Students s:list)
	          {
	              System.out.println(s.name+"  "+s.marks1+" "+s.marks2+" "+s.marks3);
	          }
	}
	 
	}
	 

	class Students
	{
	    String name;
	    String marks1,marks2,marks3;
	    public Students(String name, String marks1,String marks2,String marks3) {
	        super();
	        this.name = name;
	        this.marks1 = marks1;
	        this.marks2 = marks2;
	        this.marks3 = marks3;

	}

}
	
	
	//Student Marks1  marks 2  marks 3
////sakshi  400/500   380/500   480/500



