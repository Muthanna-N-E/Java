package project1;

import java.util.ArrayList;

public class test {

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<>();
		list.add("java");
		list.add("sql");
		list.add("php");
		
		
		for(String x:list) {
			System.out.println(x);
		}
		
		
	     

	}

}









//ArrayList<String> list=new ArrayList<>();//Object
//list.add("java");
//list.add("php");
//list.add("python");
//
//for(String x  : list)
//{
//System.out.println(x);    
//}