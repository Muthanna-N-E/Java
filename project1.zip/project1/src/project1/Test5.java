package project1;

import java.util.ArrayList;

public class Test5 {

	public static void main(String[] args) {
		ArrayList<Student> list=new ArrayList<>();//Object
        Student s1=new Student("Java", 9);
        Student s2=new Student("Android", 9);
        Student s3=new Student("python", 9);
        
       

          list.add(s1);
          list.add(s2);
          list.add(s3);
         
          for( Student s:list)
          {
              System.out.println(s.languages+"  "+s.marks);
          }
}
 
}
 

class Student
{
    String languages;
    int marks;
    public Student(String languages, int marks) {
        super();
        this.languages = languages;
        this.marks = marks;

	}

}




