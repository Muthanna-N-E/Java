package project2;

import java.util.HashMap;

public class Clear {

	public static void main(String[] args) {
		
        HashMap<Integer, String> hash_map = new HashMap<Integer, String>();
        hash_map.put(10, "asdf");
        hash_map.put(15, "asac");
        hash_map.put(20, "dfgs");
        System.out.println("Initial Mappings are: " + hash_map); 
        hash_map.clear();      
        System.out.println("Finally the maps look like this: " + hash_map);

	}

}
