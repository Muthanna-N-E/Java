package project2;

import java.util.HashMap;
import java.util.Map;

public class Tst5 {

	public static void main(String[] args) {
		HashMap<String,Student>map =new HashMap<>();
		Student s1=new Student("abc","123");
		Student s2=new Student("abc","123");
		Student s3=new Student("abc","123");



		map.put("Student1",s1);
		map.put("Student2",s2);
		map.put("Student3",s3);
		
		for(Map.Entry<String,Student> me:map.entrySet())
		{
			System.out.println(me.getKey()+" : "+me.getValue().name+" "+me.getValue().pass);
		}
		
		

	}

}

class Student
{
	String name,pass;
	public Student(String name,String pass)
	{
		super();
		this.name=name;
		this.pass=pass;
	}
}
