package project2;

import java.util.HashMap;
import java.util.Map;

public class Tst7 {

	public static void main(String[] args) {
		HashMap<String,Employee>map =new HashMap<>();
		Employee s1=new Employee("abc","123","Rs.23000");
		Employee s2=new Employee("adsc","144","Rs.33000");
		Employee s3=new Employee("hggs","121","Rs.530000");



		map.put("Employee1",s1);
		map.put("Employee2",s2);
		map.put("Employee3",s3);
		
		for(Map.Entry<String,Employee> me:map.entrySet())
		{
			System.out.println(me.getKey()+" : "+me.getValue().name+" "+me.getValue().id+" "+me.getValue().salary);
		}
		
		

	}

}

class Employee
{
	String name,id,salary;
	public Employee(String name,String id,String salary)
	{
		super();
		this.name=name;
		this.id=id;
		this.salary=salary;


	}

}
