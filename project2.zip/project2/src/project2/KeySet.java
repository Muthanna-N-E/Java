package project2;

import java.util.HashMap;

public class KeySet {

	public static void main(String[] args) {
        HashMap<Integer, String> hash_map = new HashMap<Integer, String>();
        hash_map.put(10, "asdfas");
        hash_map.put(15, "4");
        hash_map.put(20, "dASFs");
        hash_map.put(25, "pkj");
        hash_map.put(30, "sdu");
        System.out.println("Initial Mappings are: " + hash_map);
        System.out.println("The set is: " + hash_map.keySet());

	}

}
