package project2;

import java.util.ArrayList;
import java.util.Scanner;

public class Tst11 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		ArrayList<Integer>list=new ArrayList<>();
		ArrayList<Integer>even=new ArrayList<>();
		ArrayList<Integer>odd=new ArrayList<>();
		ArrayList<Integer>prime=new ArrayList<>();
		System.out.println("Enter the numbers");
		for(int i=1;i<=10;i++)
		{
			int a=s.nextInt();
		list.add(a);
		}
		int flag=0;
		for(int l:list)
		{
			if(l%2==0)
			{
				even.add(l);
			}
			else
			{
				odd.add(l);
				for(int i=2;i<=(l/2);i++) {
					if(l%i!=0){
						flag=1;
						break;
					}
			}
				if(flag==0)
				{
					prime.add(l);
				}
			}
		}
	System.out.println("Even numbers are "+even);
	System.out.println("Odd numbers are "+odd);
	System.out.println("Prime numbers are "+prime);
	}

}
