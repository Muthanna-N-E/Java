package project2;

import java.util.ArrayList;


public class Tst9 {

	public static void main(String[] args) {
	ArrayList<String>list=new ArrayList<>();
	list.add("abc");
	list.add("kjj");
	ArrayList<String>list1=new ArrayList<>();
	list1.add("dfgc");
	list1.add("efaj");
	list.addAll(list1);
	for(String x:list)
	{
		System.out.println(x);
	}

	}

}
