package project2;

import java.util.HashMap;
import java.util.Map;

public class Tst2 {

	public static void main(String[] args) {
		HashMap<String,String>map =new HashMap<>();
		map.put("color1", "red");
		map.put("color2", "black");
		map.put("color3", "blue");
		
		for(Map.Entry<String,String> me:map.entrySet())
		{
			System.out.println(me.getKey()+" and "+me.getValue());
		}


	}

}
