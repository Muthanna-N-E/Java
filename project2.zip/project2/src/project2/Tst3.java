package project2;

import java.util.HashMap;
import java.util.Map;

public class Tst3 {

	public static void main(String[] args) {
		HashMap<String,Integer>map =new HashMap<>();
		map.put("java", 80);
		map.put("php", 70);
		map.put("python", 90);
		
		for(Map.Entry<String,Integer> me:map.entrySet())
		{
			System.out.println(me.getKey()+" : "+me.getValue());
		}

	}

}
