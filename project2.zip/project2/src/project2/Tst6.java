package project2;

import java.util.HashMap;
import java.util.Map;

public class Tst6 {

	public static void main(String[] args) {
		HashMap<String,Books>map =new HashMap<>();
		Books s1=new Books("abc","123","Rs.230");
		Books s2=new Books("adsc","144","Rs.330");
		Books s3=new Books("hggs","121","Rs.530");



		map.put("Books1",s1);
		map.put("Books2",s2);
		map.put("Books3",s3);
		
		for(Map.Entry<String,Books> me:map.entrySet())
		{
			System.out.println(me.getKey()+" : "+me.getValue().name+" "+me.getValue().id+" "+me.getValue().price);
		}
		
		

	}

}

class Books
{
	String name,id,price;
	public Books(String name,String id,String price)
	{
		super();
		this.name=name;
		this.id=id;
		this.price=price;

	}

}
