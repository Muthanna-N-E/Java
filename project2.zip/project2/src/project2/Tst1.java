package project2;

import java.util.HashMap;

public class Tst1 {

	public static void main(String[] args) {
		HashMap<Integer,String>map =new HashMap<>();
		map.put(1, "abc");
		map.put(2, "rrc");
		map.put(4, "eec");
		System.out.print(map);

	}

}
