package project2;

import java.util.HashMap;
import java.util.Map;

public class Tst8 {

	public static void main(String[] args) {
		HashMap<String,Teacher>map =new HashMap<>();
		Teacher s1=new Teacher("abc","123","2");
		Teacher s2=new Teacher("adsc","144","3");
		Teacher s3=new Teacher("hggs","121","5");



		map.put("Teacher1",s1);
		map.put("Teacher2",s2);
		map.put("Teacher3",s3);
		
		for(Map.Entry<String,Teacher> me:map.entrySet())
		{
			System.out.println(me.getKey()+" : "+me.getValue().name+" "+me.getValue().id+" "+me.getValue().classs);
		}
		
		

	}

}

class Teacher
{
	String name,id,classs;
	public Teacher(String name,String id,String classs)
	{
		super();
		this.name=name;
		this.id=id;
		this.classs=classs;


	}

}
