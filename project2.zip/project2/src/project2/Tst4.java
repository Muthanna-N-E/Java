package project2;

import java.util.HashMap;
import java.util.Map;

public class Tst4 {

	public static void main(String[] args) {
		HashMap<Integer,String>map =new HashMap<>();
		map.put(1, "Ram");
		map.put(2, "Paul");
		map.put(3, "Rossi");
		map.put(4, "Vettel");
		
		for(Map.Entry<Integer,String> me:map.entrySet())
		{
			System.out.println(me.getKey()+" : "+me.getValue());
		}

	}

}
