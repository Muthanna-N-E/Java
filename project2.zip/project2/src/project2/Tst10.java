package project2;

import java.util.ArrayList;

import java.util.Scanner;


public class Tst10 {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		ArrayList<Integer>even=new ArrayList<>();
		ArrayList<Integer>odd=new ArrayList<>();
		ArrayList<Integer>prime=new ArrayList<>();

		System.out.println("Enter total numbers");
		int nn=s.nextInt();
		System.out.println("Enter the numbers");
		for(int i=0;i<nn;i++)
		{
		int n=s.nextInt();
		if(n%2==0||n==2)
		{
		even.add(n);
		}
		else
		{
		for(int j=2;j<=(n/2);j++) {
		if(n%j!=0){
		prime.add(n);
		}

		else {
		odd.add(n);
		}
		}
		}
		}
		for(int a:even)
		{
		System.out.println("Even numbers are:"+a);
		}
		for(int b:odd)
		{
		System.out.println("odd numbers are:"+b);
		}
		for(int c:prime)
		{
		System.out.println("prime numbers are:"+c);
		}
		
		
		
//		int[] myArray={1,3,4,2,12,10,8,7,6,5,9,14} ;
//		ArrayList<Integer>evenList = new ArrayList<Integer>();
//		ArrayList<Integer>oddList = new ArrayList<Integer>();
//
//		for(int i=0;i<myArray.length;i++){
//		if(myArray[i]%2==0){
//		evenList.add(myArray[i]);
//		}else{
//		oddList.add(myArray[i]);
//		}
//		}
//		Collections.sort(evenList);
//		Collections.sort(oddList);
//		
//		System.out.print(evenList+",");
//		
//		System.out.println(oddList+",");
		
		
//		ArrayList<Integer>even=new ArrayList<>();
//		ArrayList<Integer>odd=new ArrayList<>();
//		ArrayList<Integer>prime=new ArrayList<>();
//		Scanner s=new Scanner(System.in);
//		System.out.println("Enter the total number");
//		int n=s.nextInt();
//		System.out.println("Enter the numbers");
//		 for (int i = 0;i<n ;i++ )
//          {
//			 int num=s.nextInt();
//                  if (n%2 == 0)
//                  {
//                          System.out.print(arr[i]+" ");
//                  }
//          }
		
		
	
		
		

		
		
//		
//		    boolean flag = false;
//		    for (int i = 2; i <= list1 / 2; ++i) {
//		      // condition for nonprime number
//		      if (list1 % i == 0) {
//		        flag = true;
//		        break;
//		      }
//		    }
//
//		    if (!flag)
//		      System.out.println(list1 + " is a prime number.");
//		    else
//		      System.out.println(list1 + " is not a prime number.");
//		
		
//		int i,m=0,flag=0;      
//		  int n=3;//it is the number to be checked    
//		  m=n/2;      
//		  if(n==0||n==1){  
//		   System.out.println(n+" is not prime number");      
//		  }else{  
//		   for(i=2;i<=m;i++){      
//		    if(n%i==0){      
//		     System.out.println(n+" is not prime number");      
//		     flag=1;      
//		     break;      
//		    }      
//		   }      
//		   if(flag==0)  { System.out.println(n+" is prime number"); }  
//		  }//end of else  

	}

}
