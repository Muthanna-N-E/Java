package project2;

import java.util.HashMap;

public class IsEmpty {

	public static void main(String[] args) {
		 
        HashMap<String, Integer> hash_map = new HashMap<String, Integer>();
        hash_map.put("asds", 10);
        hash_map.put("4", 15);
        hash_map.put("sdfg", 20);
        hash_map.put("abc", 25);
        hash_map.put("pkj", 30);
        System.out.println("The Mappings are: " + hash_map);
        System.out.println("Is the map empty? " + hash_map.isEmpty());

	}

}
